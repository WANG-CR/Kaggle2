import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import sklearn
from sklearn.naive_bayes import MultinomialNB
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.svm import SVC

import re
import pickle

def load_dataset():
    train_data = pd.read_csv('data/train_data.csv')['text']
    test_data = pd.read_csv('data/test_data.csv')['text']
    
    counts = {"negative": 0, "neutral": 0, "positive":0}
    train_label = pd.read_csv('data/train_results.csv')
    train_label = np.array([list(counts).index(i) for i in train_label["target"]])
    return train_data, train_label, test_data

def train_tokenizer(train_data, max_features):
    vectorizer = CountVectorizer(min_df=1, lowercase=True, max_features=max_features)
    vectorizer.fit(train_data)
    return vectorizer

def vectorize(vectorizer, text):
    BOW = vectorizer.transform(text).toarray()
    return BOW 

def save_df(test_labels, save_as_name):
    df = pd.DataFrame({'target':test_labels})
    df.index.name = 'id'
    df.to_csv(save_as_name + ".csv")
    print('save to: ' + save_as_name + '.csv')

def string_kernel(X,Y):
    print(f"X shape is {X.shape}")
    y = Y>0
    kernel_result = []
    for Xi in X:
        x = X>0
        equals = np.logical_and(x[0],y).sum(axis=-1)
    kernel_result.append(equals[None,:])
    return np.concatenate(kernel_result, axis=0)


# def convert_BOW_to_string_1D(x):
#     z = []
#     for sample in x:
#         y = np.array([index for index, value in enumerate (sample) if value > 0], )
#         z.append(y)
#     return z

# def string_kernel(X, Y):
#     #  R = np.zeros((len(X), len(Y)))
#     # print(f"X is")
#     # print(X)
#     # print(f"Y is")
#     # print(Y)
#     r = 0
#     #  for i, x in enumerate(X):
#     #      for j, y in enumerate(Y):
#     # for x in X:
#     #     for y in Y:
#              # simplest kernel ever
#             # print(f"x is")
#             # print(x)
#             # print(f"y is")
#             # print(y)
#             # print(f"x==y is")
#             # print(x==y)
#             # if x==y:
#             #     r = r + 1
#     return r

max_features = 1000
train_data, train_label, test_data = load_dataset()
print(f"test data shape before preprocessing is {test_data.shape}")

with open('preprocess_test.txt', 'rb') as fp:
    test_data = pickle.load(fp)
with open('preprocess_train.txt', 'rb') as fp:
    train_data = pickle.load(fp)
vectorizer= train_tokenizer(train_data, max_features)
train_feature = vectorize(vectorizer, train_data)
test_feature = vectorize(vectorizer, test_data)

# train_feature = convert_BOW_to_string_1D(train_feature)
# test_feature = convert_BOW_to_string_1D(test_feature)
# print(f"train_feature.shape is {train_feature[0].shape}")

print(f"training SVM with string kernels.......")
# model = SVC(kernel = string_kernel, cache_size=8000, C=0.01)
model = SVC(cache_size=8000, C=0.01)
model.fit(train_feature[:100000],train_label[:100000])
print(f"predicting SVM with string kernels.......")
test_labels = model.predict(test_feature)
print(test_labels.shape)
save_df(test_labels, "SVM_LinearKernel_"+ str(max_features)+"feature")

