import math
from time import time

import torch as th
from tqdm import tqdm

import utils.func as uf
from utils.data.pre_process import *
from utils.modules.early_stopper import EarlyStopping
from utils.modules.model_conf import ModelConfig


def plot_img(x):
    from matplotlib import pyplot as plt
    plt.imshow(x.reshape((28, 56)), interpolation='nearest')
    plt.show()


LOG_FREQ = 1


class TextClaTrainer:
    '''
    Use combined image as trainer
    '''

    def __init__(self, cf: ModelConfig):
        self.cf, self.logger = cf, cf.logger
        self.log = self.cf.logger.log
        self.wandb_prefix = cf.wandb_prefix if hasattr(cf, 'wandb_prefix') else ''
        self.device = cf.device

        # ! Load data
        train_text, train_y, test_text = load_data(cf.process_mode)

        N = len(train_text)
        n = math.ceil(N * 0.9)
        _ = np.random.permutation(np.arange(N))
        train_ids, val_ids = _[:n], _[n:]
        self.train_x, self.val_x = train_text[train_ids], train_text[val_ids]
        self.train_y, self.val_y = train_y[train_ids], train_y[val_ids]
        self.test_x = test_text

        self.stopper = EarlyStopping(patience=cf.early_stop, path=cf.checkpoint_file) if cf.early_stop > 0 else None
        self.model = None

        self.training_start_time = time()
        self.logger = cf.logger
        self.log = cf.logger.log

    def _train_epoch(self, permuted):
        pass

    def _train_callback(self):
        pass

    @uf.time_logger
    def train(self):
        N = len(self.train_x)
        for epoch in range(self.cf.epochs):
            # ! Shuffle dataset
            t0, es_str = time(), ''
            permuted = np.random.permutation(np.arange(N))
            # ! rain
            loss = self._train_epoch(permuted)
            # ! Validation
            train_acc, val_acc = self.eval()
            es_flag, es_str = self.stopper.step(val_acc, self.model, epoch)
            log_dict = {'Epoch': epoch, 'Time': time() - t0,
                        'Loss': loss, 'TrainAcc': train_acc,
                        'ValAcc': val_acc, 'ES': es_str}
            self.logger.dynamic_log(log_dict, 1 if epoch % LOG_FREQ == 0 else 2)
            if self.cf.early_stop > 0:
                es_flag, es_str = self.stopper.step(val_acc, self.model, epoch)
                if es_flag:
                    print(f'Early stopped, loading model from epoch-{self.stopper.best_epoch}')
                    break
        self._train_callback()

    @th.no_grad()
    def _get_logits(self, x):
        logits = np.zeros((x.shape[0], self.cf.n_class))
        for i in range(0, N := x.shape[0], chunk := 20000):
            ids = range(i, min(i + chunk, N))
            logits[ids] = self.model.predict(x[ids])
        return logits

    def predict(self, x, logits_file=''):
        logits = self._get_logits(x)
        return np.argmax(logits, axis=1)

    def save_test(self, pred, f):
        df_pred = pd.DataFrame(pred, columns=["target"])
        df_pred["id"] = range(pred.shape[0])
        df_pred = df_pred[["id", "target"]]
        _ = {2: 'positive', 0: 'negative', 1: 'neutral'}
        df_pred['target'] = df_pred['target'].replace(_)
        df_pred.to_csv(f, index=False)
        self.logger.log(f'Test predictions saved to {f}')

    def eval_and_save_test(self):
        # ! Final eval
        train_acc, val_acc = self.eval()
        res_data = {'TrainAcc': train_acc, 'ValAcc': val_acc}
        self.logger.save(res_data)
        self.logger.log(f'Training completed!\n{res_data}')
        f = uf.init_path(f'output/test_pred@Val{val_acc}.csv')

        # ! Save test
        pred = np.argmax(self.trainer.predict(self.val_data).predictions, axis=1).astype('str')
        self.save_test(pred, f)

    def bagging(self):
        pred = bagging('output/bagging/')
        self.save_test(pred, f := f'output/bagging.csv')
        self.logger.log(f'Test predictions saved to {f}')
