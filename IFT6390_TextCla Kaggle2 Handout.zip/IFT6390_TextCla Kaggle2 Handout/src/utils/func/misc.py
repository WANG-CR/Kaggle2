import os
import pickle


def pickle_save(var, f_name):
    pickle.dump(var, open(f_name, 'wb'))
    print(f'Saved {f_name}')


def pickle_load(f_name):
    return pickle.load(open(f_name, 'rb'))


def floor_quantize(val, to_values):
    """Quantize a value with regard to a set of allowed values.

    Examples:
        quantize(49.513, [0, 45, 90]) -> 45
        quantize(17, [0, 10, 20, 30]) -> 10 # FLOORED

    Note: metrics doesn't assume to_values to be sorted and
    iterates over all values (i.e. is rather slow).

    Args:
        val        The value to quantize
        to_values  The allowed values
    Returns:
        Closest value among allowed values.
    """
    best_match = None
    best_match_diff = None
    assert min(to_values) <= val
    for other_val in to_values:
        if other_val <= val:  # Floored (only smaller values are matched)
            diff = abs(other_val - val)
            if best_match is None or diff < best_match_diff:
                best_match = other_val
                best_match_diff = diff
    return best_match


def get_max_batch_size(gpu_mem, max_bsz_dict):
    quantized_gpu_mem = floor_quantize(gpu_mem, max_bsz_dict.keys())
    return max_bsz_dict[quantized_gpu_mem]


def calc_bsz_grad_acc(eq_batch_size, max_bsz_dict, sv_info, min_bsz=2):
    if sv_info.gpu_mem == 0:
        return eq_batch_size, 1
    max_bsz_per_gpu = get_max_batch_size(sv_info.gpu_mem, max_bsz_dict)
    gpus = os.environ['CUDA_VISIBLE_DEVICES']
    n_gpus = len(gpus.split(',')) if gpus != '' else 1
    print(f'N-GPUs={n_gpus}')

    def find_grad_acc_steps(bsz_per_gpu):
        # Find batch_size and grad_acc_steps combination that are DIVISIBLE!
        grad_acc_steps = eq_batch_size / bsz_per_gpu / n_gpus
        if grad_acc_steps.is_integer():
            return bsz_per_gpu, int(grad_acc_steps)
        elif grad_acc_steps:
            if bsz_per_gpu >= min_bsz:
                return find_grad_acc_steps(bsz_per_gpu - 1)
            else:
                raise ValueError(
                    f'Cannot find grad_acc_step with integer batch_size greater than {min_bsz}, eq_bsz={eq_batch_size}, n_gpus={n_gpus}')

    batch_size, grad_acc_steps = find_grad_acc_steps(max_bsz_per_gpu)
    print(f'Eq_batch_size = {eq_batch_size}, bsz={batch_size}, grad_acc_steps={grad_acc_steps}, ngpus={n_gpus}')
    return batch_size, grad_acc_steps
