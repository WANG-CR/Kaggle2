import numpy as np
import os
from scipy.special import softmax


def sigmoid(x):
    x = x.astype(float)
    x = z_norm(x)

    return 1.0 / (1.0 + np.exp(-1 * x))


def feature_likelihood(data, training_label, number_of_data_type, m_estimate=1.0):
    pos_likelihood = np.zeros(number_of_data_type)
    neg_likelihood = np.zeros(number_of_data_type)
    pos_num = np.sum(training_label)
    neg_num = len(training_label) - pos_num

    if m_estimate >= 0:
        m = m_estimate

    for i in range(0, data.shape[0]):
        if training_label[i] == 1:
            pos_likelihood[int(data[i])] += 1
        else:
            neg_likelihood[int(data[i])] += 1

    pos_likelihood = [[(x + m) / (pos_num + m * number_of_data_type) for x in pos_likelihood]]
    neg_likelihood = [[(x + m) / (neg_num + m * number_of_data_type) for x in neg_likelihood]]

    likelihood = pos_likelihood + neg_likelihood

    return likelihood


def continuous_feature_likelihood(data, pos_index, neg_index):
    # pos_index = np.where(training_label == 1)[0]
    # neg_index = np.where(training_label == 0)[0]
    pos_data = data[pos_index]
    neg_data = data[neg_index]

    pos_mu = np.mean(pos_data)
    pos_theta = np.std(pos_data)
    pos_para = [[pos_mu, pos_theta]]
    neg_mu = np.mean(neg_data)
    neg_theta = np.std(neg_data)
    neg_para = [[neg_mu, neg_theta]]

    likelihood = pos_para + neg_para

    return likelihood


def Gaussian_probability_compute(likelihood, sample, info):
    pred_pos = 0
    pred_neg = 0
    for i in range(0, len(sample)):

        if info[i].type == 'CONTINUOUS':

            gaussian_pos = GaussianNB(likelihood[i][0], sample[i])
            gaussian_neg = GaussianNB(likelihood[i][1], sample[i])

            if gaussian_pos <= 1e-300 or gaussian_neg <= 1e-300:
                pred_pos += np.log(1e-300)
                pred_neg += np.log(1e-300)
            else:
                pred_pos += np.log(gaussian_pos)
                pred_neg += np.log(gaussian_neg)

            # try:
            #     pred_pos += np.log(GaussianNB(likelihood[i][0], sample[i]))
            #     pred_neg += np.log(GaussianNB(likelihood[i][1], sample[i]))
            # except:
            #     pred_pos += np.log(1e-100)
            #     pred_neg += np.log(1e-100)

        else:
            pred_pos += np.log(likelihood[i][0][int(sample[i])])
            pred_neg += np.log(likelihood[i][1][int(sample[i])])

    pred_pos += np.log(likelihood[-1][0][0])
    pred_neg += np.log(likelihood[-1][1][0])

    pred = [pred_neg, pred_pos]

    return pred


def Probability_compute(likelihood, sample):
    pred_pos = 0
    pred_neg = 0
    for i in range(0, len(sample)):
        pred_pos += np.log(likelihood[i][0][int(sample[i])])
        pred_neg += np.log(likelihood[i][1][int(sample[i])])

    pred_pos += np.log(likelihood[-1][0][0])
    pred_neg += np.log(likelihood[-1][1][0])

    pred = [pred_neg, pred_pos]

    return pred


def split_continuous_into_kbins(data, info, k):
    for i in range(1, len(info) - 1):
        if info[i].type == "CONTINUOUS":
            min_value = min(data[:, i])
            max_value = max(data[:, i])
            interval = (max_value - min_value) / k

            data[:, i] = (data[:, i] - min_value) // interval

            for j in range(data.shape[0]):
                if data[j][i] == k:
                    data[j][i] = k - 1

    data = data.astype(int)
    return data


def GaussianNB(para, value):
    pi = np.pi
    mu = para[0]
    theta = para[1]
    value = float(value)
    if theta > 0:
        W = 1.0 / np.sqrt(2.0 * pi * theta ** 2.0)
        X = (-1.0 * (value - mu) ** 2.0) / (2.0 * theta ** 2.0)
        pred = W * np.exp(X)
    else:
        pred = 1.0

    return pred


def z_norm(x):
    m = np.mean(x)
    s = np.std(x)
    if s != 0:
        x = (x - m) / s
    return x


def min_max_norm(x):
    min = x.min(axis=0)
    max = x.max(axis=0)
    dist = max - min
    x = (x - min) / dist
    x = np.nan_to_num(x)
    return x


def sigmoid(x):
    x = x.astype(float)
    x = z_norm(x)

    return 1.0 / (1.0 + np.exp(-1 * x))


def one_hot(a, num_classes):
    return np.squeeze(np.eye(num_classes)[a.reshape(-1)])


def AUC_compute(TP, TN, FP, FN):
    TPR = TP.astype(float) / (TP + FN).astype(float)
    FPR = FP.astype(float) / (TN + FP).astype(float)

    # FPR = FPR.tolist()
    # FPR = [round(x,3) for x in FPR]
    # TPR = TPR.tolist()
    # TPR = [round(x,3) for x in TPR]
    # print(FPR)
    # print(TPR)
    AUC = intergrate(FPR, TPR)

    return AUC


def intergrate(X, Y):
    prev_x = 0.0
    area = 0.0
    for i in range(len(X)):
        x = X[i]
        y = Y[i]
        if x != prev_x:
            area += (x - prev_x) * y
        prev_x = x

    return area


def list_dir(dir_name, error_msg=None):
    try:
        f_list = os.listdir(dir_name)
        return f_list
    except FileNotFoundError:
        if error_msg is not None:
            print(f'{error_msg}')
        return []


def bagging(folder):
    import pickle

    _ = [softmax(pickle.load(open(folder+f, 'rb')), axis=1)
         for f in list_dir(folder)]
    mean_logits = sum(_) / len(_)
    return np.argmax(mean_logits, axis=1)

