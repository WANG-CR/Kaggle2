import os.path as osp
import subprocess as sp
from pathlib import Path
from types import SimpleNamespace as SN

PROJ_ROOT = osp.abspath(osp.dirname(__file__)).split('src')[0]
PROJ_NAME = 'TextCla'
# Temp paths: discarded when container is destroyed
TEMP_DIR = MNT_DIR = PROJ_DIR = PROJ_ROOT
TEMP_PATH = f'{TEMP_DIR}temp/'
LOG_PATH = f'{TEMP_DIR}log/'

# ! Default Settings
DEFAULT_DATASET = 'TextCla'
EARLY_STOP = 30
MAX_EPOCHS = 3

DATA_PATH = f'{PROJ_ROOT}data/'
TEMP_RES_PATH = f'{PROJ_ROOT}temp/'
DEFAULT_TR_RATIO = 0.8
DEFAULT_GPU = '-1'  # Train on CPU

# ! Data
MAX_DATA_SAMPLES = 200
MAX_DATA_SAMPLES = 100070111


class ServerInfo:
    def __init__(self):
        self.gpu_mem, self.gpus, self.n_gpus = 0, [], 0
        try:
            import numpy as np
            command = "nvidia-smi --query-gpu=memory.total --format=csv"
            gpus = sp.check_output(command.split()).decode('ascii').split('\n')[:-1][1:]
            self.gpus = np.array(range(len(gpus)))
            self.n_gpus = len(gpus)
            self.gpu_mem = round(int(gpus[0].split()[0]) / 1024)
            self.sv_type = f'{self.gpu_mem}Gx{self.n_gpus}'
        except:
            print('NVIDIA-GPU not found, set to CPU.')
            self.sv_type = f'CPU'

    def __str__(self):
        return f'SERVER INFO: {self.sv_type}'


SV_INFO = ServerInfo()
