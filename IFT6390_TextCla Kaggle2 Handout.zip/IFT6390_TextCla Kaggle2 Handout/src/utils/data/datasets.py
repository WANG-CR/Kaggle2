from utils.func import *
from utils.settings import *
import torch as th


class TextClaDataset(th.utils.data.Dataset):
    """
    Return Bert tokens and labels
    """

    def __init__(self, tokens, labels):
        super().__init__()
        self.tokens = tokens
        self.labels = labels

    def __getitem__(self, node_id):
        return {**{k: v[node_id] for k, v in self.tokens.items()}, 'labels': self.labels[node_id]}

    def __len__(self):
        return len(self.tokens['input_ids'])
