import os.path
import re
import string

import pandas as pd

import utils.func as uf
from utils.func.np_utils import *
from utils.settings import *
from .preprocess_resources import *


@uf.time_logger
def text_cleaning(df, process_mode):
    from nltk.corpus import stopwords
    import nltk

    # https://www.kaggle.com/code/sudalairajkumar/getting-started-with-text-preprocessing/notebook
    judge = lambda s, m=process_mode: (s in m or 'ALL' in m) and (f'WO{s}' not in m)

    pd.options.mode.chained_assignment = None
    # df = df.head(10000)  # Debug only

    # ! Lower Casing
    df["text"] = df["text"].astype(str).str.lower()

    # ! Removal of Punctuations
    #
    # One another common text preprocessing technique is to remove the punctuations from the text data. This is again a text standardization process that will help to treat 'hurray' and 'hurray!' in the same way.
    # We also need to carefully choose the list of punctuations to exclude depending on the use case. For example, the `string.punctuation` in python contains the following punctuation symbols

    PUNCT_TO_REMOVE = string.punctuation

    def remove_punctuation(text):
        """custom function to remove the punctuation"""
        return text.translate(str.maketrans('', '', PUNCT_TO_REMOVE))

    # ! Removal of stopwords
    #
    # Stopwords are commonly occuring words in a language like 'the', 'a' and so on. They can be removed from the text most of the times, as they don't provide valuable information for downstream analysis. In cases like Part of Speech tagging, we should not remove them as provide very valuable information about the POS.
    # These stopword lists are already compiled for different languages and we can safely use them. For example, the stopword list for english language from the nltk package can be seen below.
    #
    # Similarly we can also get the list for other languages as well and use them.

    STOPWORDS = set(stopwords.words('english'))

    def remove_stopwords(text):
        # nltk.download('stopwords')
        # python3 -m nltk.downloader stopwords
        """custom function to remove the stopwords"""
        return " ".join([word for word in str(text).split() if word not in STOPWORDS])

    # ! Stemming
    #
    # Stemming is the process of reducing inflected (or sometimes derived) words to their word stem, base or root form (From [Wikipedia](https://en.wikipedia.org/wiki/Stemming))
    # For example, if there are two words in the corpus `walks` and `walking`, then stemming will stem the suffix to make them `walk`. But say in another example, we have two words `console` and `consoling`, the stemmer will remove the suffix and make them `consol` which is not a proper english word.
    # There are several type of stemming algorithms available and one of the famous one is porter stemmer which is widely used. We can use nltk package for the same.

    from nltk.stem.porter import PorterStemmer
    stemmer = PorterStemmer()

    def stem_words(text):
        return " ".join([stemmer.stem(word) for word in text.split()])

    # ! Lemmatization
    #
    # Lemmatization is similar to stemming in reducing inflected words to their word stem but differs in the way that it makes sure the root word (also called as lemma) belongs to the language.
    #
    # As a result, this one is generally slower than stemming process. So depending on the speed requirement, we can choose to use either stemming or lemmatization.
    # Let us use the `WordNetLemmatizer` in nltk to lemmatize our sentences
    # Now let us redo the lemmatization process for our dataset.

    from nltk.corpus import wordnet
    from nltk.stem import WordNetLemmatizer

    # !  python3 -m nltk.downloader wordnet

    lemmatizer = WordNetLemmatizer()
    wordnet_map = {"N": wordnet.NOUN, "V": wordnet.VERB, "J": wordnet.ADJ, "R": wordnet.ADV}

    def lemmatize_words(text):
        pos_tagged_text = nltk.pos_tag(text.split())
        return " ".join(
            [lemmatizer.lemmatize(word, wordnet_map.get(pos[0], wordnet.NOUN)) for word, pos in pos_tagged_text])

    # ! Removal of Emoticons
    #
    # This is what we did in the last step right? Nope. We did remove emojis in the last step but not emoticons. There is a minor difference between emojis and emoticons.
    #
    # From Grammarist.com, emoticon is built from keyboard characters that when put together in a certain way represent a facial expression, an emoji is an actual image.
    #
    #
    # Conversion of Emoticon to Words¶
    # In the previous step, we have removed the emoticons. In case of use cases like sentiment analysis, the emoticons give some valuable information and so removing them might not be a good solution. What can we do in such cases?
    #
    # One way is to convert the emoticons to word format so that they can be used in downstream modeling processes. Thanks for Neel again for the wonderful dictionary that we have used in the previous step. We are going to use that again for conversion of emoticons to words.

    def convert_emoticons(text):
        for emot in EMOTICONS:
            text = re.sub(u'(' + emot + ')', "_".join(EMOTICONS[emot].replace(",", "").split()), text)
        return text

    # ! Removal of URLs
    #
    # Next preprocessing step is to remove any URLs present in the data. For example, if we are doing a twitter analysis, then there is a good chance that the tweet will have some URL in it. Probably we might need to remove them for our further analysis.
    #
    # We can use the below code snippet to do that.

    def remove_urls(text):
        url_pattern = re.compile(r'https?://\S+|www\.\S+')
        return url_pattern.sub(r'', text)

    # ! Removal of HTML Tags

    from bs4 import BeautifulSoup

    def remove_html(text):
        return BeautifulSoup(text, "lxml").text

    # ! Chat Words Conversion
    #
    # This is an important text preprocessing step if we are dealing with chat data. People do use a lot of abbreviated words in chat and so it might be helpful to expand those words for our analysis purposes.
    # Got a good list of chat slang words from this [repo](https://github.com/rishabhverma17/sms_slang_translator/blob/master/slang.txt). We can use this for our conversion here. We can add more words to this list.

    # %% [code] {"_kg_hide-input":true,"_kg_hide-output":true}

    chat_words_map_dict = {}
    chat_words_list = []
    for line in CHAT_WORDS.split("\n"):
        if line != "":
            cw = line.split("=")[0]
            cw_expanded = line.split("=")[1]
            chat_words_list.append(cw)
            chat_words_map_dict[cw] = cw_expanded
    chat_words_list = set(chat_words_list)

    def chat_words_conversion(text):
        new_text = []
        for w in text.split():
            if w.upper() in chat_words_list:
                new_text.append(chat_words_map_dict[w.upper()])
            else:
                new_text.append(w)
        return " ".join(new_text)

    def correct_spellings(text):
        from spellchecker import SpellChecker

        spell = SpellChecker()

        corrected_text = []
        misspelled_words = spell.unknown(text.split())
        for word in text.split():
            if word in misspelled_words:
                corrected_text.append(spell.correction(word))
            else:
                corrected_text.append(word)
        try:
            return " ".join(corrected_text)
        except:
            return " ".join([_ for _ in corrected_text if isinstance(_, str)])

    # if judge('correct_spellings'):
    #     print('Text cleaning: correct_spellings')
    #     df["text"] = df["text"].apply(lambda text: correct_spellings(text))
    if judge('remove_punctuation'):
        print('Text cleaning: remove_punctuation')
        df["text"] = df["text"].apply(lambda text: remove_punctuation(text))
    if judge('remove_stopwords'):
        print('Text cleaning: remove_stopwords')
        df["text"] = df["text"].apply(lambda text: remove_stopwords(text))
    if judge('stem_words'):
        print('Text cleaning: stem_words')
        df["text"] = df["text"].apply(lambda text: stem_words(text))
    if judge('lemmatize_words'):
        print('Text cleaning: lemmatize_words')
        df["text"] = df["text"].apply(lambda text: lemmatize_words(text))
    if judge('convert_emoticons'):
        print('Text cleaning: convert_emoticons')
        df["text"] = df["text"].apply(lambda text: convert_emoticons(text))
    if judge('remove_urls'):
        print('Text cleaning: remove_urls')
        df["text"] = df["text"].apply(lambda text: remove_urls(text))
    if judge('remove_html'):
        print('Text cleaning: remove_html')
        df["text"] = df["text"].apply(lambda text: remove_html(text))
    if judge('chat_words_conversion'):
        print('Text cleaning: chat_words_conversion')
        df["text"] = df["text"].apply(lambda text: chat_words_conversion(text))
    return df


def load_data(mode=''):
    if os.path.exists(f := f'data/processed_text{mode}.pkl'):
        train_text, train_y, test_text = uf.pickle_load(f)
    else:
        train_df = pd.read_csv(f"{DATA_PATH}train_data.csv")
        test_df = pd.read_csv(f"{DATA_PATH}test_data.csv")
        full_df = pd.concat((train_df, test_df))
        processed_df = text_cleaning(full_df, process_mode=mode)

        train_text = processed_df.iloc[range(len(train_df))]['text'].tolist()
        test_text = processed_df.iloc[len(train_df):]['text'].tolist()

        _ = {'positive': 2, 'negative': 0, 'neutral': 1}
        train_y = pd.read_csv(f"{DATA_PATH}train_results.csv")
        train_y = train_y['target'].replace(_).astype(int).tolist()
        uf.pickle_save((train_text, train_y, test_text), f)
    return np.array(train_text), np.array(train_y), np.array(test_text)
