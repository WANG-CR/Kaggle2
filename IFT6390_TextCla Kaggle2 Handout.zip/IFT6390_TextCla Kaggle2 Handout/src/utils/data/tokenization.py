import os.path

from transformers import AutoTokenizer

from tokenizers import BertWordPieceTokenizer
from tqdm.auto import tqdm
from pathlib import Path
from transformers import BertTokenizer

import utils.func as uf
import re


def load_tokenizer(cf, dataset):
    text_data = []
    file_count = 0
    temp_path = uf.init_path('data/token_temp/')
    if not os.path.exists(uf.init_path(cf.tokenizer_path + 'vocab.txt')):
        for i in tqdm(range(len(dataset)), desc='Splitting text'):
            # remove newline characters from each sample as we need to use exclusively as seperators
            text = dataset[i].replace('\n', '\s').strip('#')
            text = re.sub(r"[^a-zA-Z0-9 ]", "", text)
            text_data.append(text)
            if len(text_data) == 50000:
                with open(f'{temp_path}text_{file_count}.txt', 'w', encoding='utf-8') as fp:
                    fp.write('\n'.join(text_data))
                text_data = []
                file_count += 1
        # after saving in 5K chunks, we may have leftover samples, we save those now too
        with open(f'{temp_path}/text_{file_count}.txt', 'w', encoding='utf-8') as fp:
            fp.write('\n'.join(text_data))

        tokenizer = BertWordPieceTokenizer(
            clean_text=True,
            handle_chinese_chars=False,
            strip_accents=False,
            lowercase=False
        )
        paths = [str(x) for x in Path(temp_path).glob('**/*.txt')]
        # and train
        tokenizer.train(files=paths, vocab_size=cf.vocab_size,
                        min_frequency=cf.min_frequency,
                        limit_alphabet=1000, wordpieces_prefix='##',
                        special_tokens=[
                            '[PAD', '[UNK]', '[CLS]', '[SEP]', '[MASK]'])
        tokenizer.save_model(cf.tokenizer_path)
    tokenizer = BertTokenizer.from_pretrained(cf.tokenizer_path)
    return tokenizer
