import numpy as np
import pandas as pd

h_list = s_list = [0.01, 0.1, 0.2, 0.3, 0.4, 0.5, 1.0, 3.0, 10.0, 20.0]


######## DO NOT MODIFY THIS FUNCTION ########
def draw_rand_label(x, label_list):
    seed = abs(np.sum(x))
    while seed < 1:
        seed = 10 * seed
    seed = int(1000000 * seed)
    np.random.seed(seed)
    return np.random.choice(label_list)


#############################################


class Q1:
    def feature_means(self, banknote):
        return np.mean(banknote[:, :-1], axis=0)

    def covariance_matrix(self, banknote):
        return np.cov(banknote[:, :-1].T)

    def feature_means_class_1(self, banknote):
        return np.mean(banknote[banknote[:, -1] == 1, :-1], axis=0)

    def covariance_matrix_class_1(self, banknote):
        return np.cov(banknote[banknote[:, -1] == 1, :-1].T)


class HardParzen:
    def __init__(self, h):
        self.h = h

    def train(self, train_inputs, train_labels):
        self.label_list = np.unique(train_labels)
        self.train_x = train_inputs
        self.train_y = train_labels.astype(np.int32)

    def compute_predictions(self, test_data):
        N = len(test_data)
        predictions = np.zeros(N)
        for i in range(N):
            x = test_data[i]
            neighbors = np.linalg.norm(x - self.train_x, axis=1) < self.h
            if sum(neighbors) > 0:
                predictions[i] = np.argmax(np.bincount(self.train_y[neighbors]))
            else:
                predictions[i] = draw_rand_label(x, self.label_list)
        return predictions


class SoftRBFParzen:
    def __init__(self, sigma):
        self.sigma = sigma

    def train(self, train_inputs, train_labels):
        self.label_list = np.unique(train_labels)
        self.train_x = train_inputs
        self.train_y = train_labels.astype(np.int32)

    def compute_predictions(self, test_data):
        N = len(test_data)
        predictions = np.zeros(N)
        d = len(self.train_x[0])
        for i in range(N):
            x = test_data[i]
            w = np.exp(-np.linalg.norm(x - self.train_x, axis=1) ** 2 / (2 * self.sigma ** 2))
            w /= self.sigma ** d * np.power(2 * np.pi, d / 2)
            predictions[i] = np.argmax(np.bincount(self.train_y, weights=w))
        return predictions


def split_dataset(banknote):
    # A training set consisting of the samples of the dataset with indices which have a remainder of either 0 or 1, or 2 when divided by 5
    # A validation set consisting of the samples of the dataset with indices which have a remainder of 3 when divided by 5.
    # A test set consisting of the samples of the dataset with indices which have a remainder of 4 when divided by 5.
    remainder = np.remainder(np.arange(len(banknote)), 5)
    return banknote[remainder < 3], banknote[remainder == 3], banknote[remainder == 4]


class ErrorRate:
    def __init__(self, x_train, y_train, x_val, y_val):
        self.x_train = x_train
        self.y_train = y_train
        self.x_val = x_val
        self.y_val = y_val

    def hard_parzen(self, h):
        hp = HardParzen(h)
        hp.train(self.x_train, self.y_train)
        hp.compute_predictions(self.x_val)
        return np.mean(hp.compute_predictions(self.x_val) != self.y_val)

    def soft_parzen(self, sigma):
        sp = SoftRBFParzen(sigma)
        sp.train(self.x_train, self.y_train)
        sp.compute_predictions(self.x_val)
        return np.mean(sp.compute_predictions(self.x_val) != self.y_val)


import matplotlib.pyplot as plt


def plot_two_lines(x, y1, y2):
    plt.plot(range(10), y1, label='Hard Parzen')
    plt.plot(range(10), y2, label='Soft Parzen')
    plt.xticks(range(10), x)
    plt.xlabel('h or sigma')
    plt.ylabel('validation error')
    plt.legend()
    plt.show()


def plot_two_lines_with_error_bar(x, y1: pd.DataFrame, y2: pd.DataFrame):
    # Error rate of 0.2 standard deviations
    plt.errorbar(range(10), y1.mean(axis=0), yerr=0.2 * y1.std(axis=0), label='Hard Parzen')
    plt.errorbar(range(10), y2.mean(axis=0), yerr=0.2 * y2.std(axis=0), label='Soft Parzen')
    plt.xticks(range(10), x)
    plt.xlabel('h or sigma')
    plt.ylabel('validation error')
    plt.legend()
    plt.show()


def get_test_errors(banknote, log=False):
    train, val, test = split_dataset(banknote)
    x_train, y_train = train[:, :-1], train[:, -1]
    x_val, y_val = val[:, :-1], val[:, -1]
    x_test, y_test = test[:, :-1], test[:, -1]
    err = ErrorRate(x_train, y_train, x_val, y_val)
    hp_val_errors = {h: err.hard_parzen(h) for h in h_list}
    sp_val_errors = {s: err.soft_parzen(s) for s in s_list}

    # get the best h and s based on validation set
    best_h = min(hp_val_errors, key=hp_val_errors.get)
    best_s = min(sp_val_errors, key=sp_val_errors.get)

    if log:
        print('<Hard Parzen Validation Errors\n', hp_val_errors)
        print('<Soft RBF Parzen Validation Errors\n', sp_val_errors)
        print(f'Best h: {best_h}, Best s: {best_s}')
        plot_two_lines(h_list, list(hp_val_errors.values()), list(sp_val_errors.values()))

        # train the model with the best h and s
        err.x_val, err.y_val = x_test, y_test
        return err.hard_parzen(best_h), err.soft_parzen(best_s)
    else:
        return hp_val_errors, sp_val_errors


def random_projections(X, A):
    return np.matmul(X, A) / np.sqrt(2)


if __name__ == '__main__':
    data = np.loadtxt('data_banknote_authentication.txt', delimiter=',')
    h_err, s_err = get_test_errors(data, True)
    # Run 500 times random projections
    from tqdm import tqdm

    h_err_list = []
    s_err_list = []
    for i in tqdm(range(500)):
        A = np.random.normal(0, 1, size=(4, 2))
        projected = random_projections(data[:, :-1], A)
        h_err, s_err = get_test_errors(np.concatenate((projected, data[:, -1].reshape(-1, 1)), axis=1))
        h_err_list.append(h_err)
        s_err_list.append(s_err)

    # pandas data frame
    h_err = pd.DataFrame(h_err_list)
    s_err = pd.DataFrame(s_err_list)

    plot_two_lines_with_error_bar(h_list, h_err, s_err)

    # print(f'Hard Parzen Test Error: {np.mean(h_err_list)}')
    # print(f'Soft Parzen Test Error: {np.mean(s_err_list)}')

    print(h_err, s_err)
