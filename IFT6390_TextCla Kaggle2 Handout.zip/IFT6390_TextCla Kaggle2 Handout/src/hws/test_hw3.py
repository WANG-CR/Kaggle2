from solution import *
import pandas as pd
import seaborn as sns
from matplotlib import pyplot as plt

# Seed all random number generators
np.random.seed(197331)
torch.manual_seed(197331)
random.seed(197331)


def get_train_log(**kwargs):
    epochs = kwargs.pop('epochs')
    trainer = Trainer(**kwargs)
    print(trainer.network)
    trainer.train_loop(epochs)
    return pd.DataFrame(trainer.train_logs)


def plot_mae(mae):
    sns.lineplot(data=pd.DataFrame(mae))
    plt.xlabel('Epochs')
    plt.ylabel('Mean Absolute Error (Test)')
    plt.legend()
    plt.show()


def plot_mlp_mae():
    plot_mae({lr: get_train_log(
        network_type="mlp", batch_size=128, lr=lr, activation_name="relu",
        net_config=NetworkConfiguration(dense_hiddens=(128, 128)), epochs=50
    )['test_mae']
              for lr in [1e-2, 1e-4, 1e-8]}
             )


def plot_cnn_mae():
    plot_mae(get_train_log(
        network_type="cnn", batch_size=128, epochs=50, activation_name="relu",
        net_config=NetworkConfiguration(
            dense_hiddens=(128, 128),
            n_channels=(16, 32, 45),
            kernel_sizes=(3, 3, 3), strides=(1, 1, 1), )
    )['test_mae']
             )


def plot_equivariance():
    trainer = Trainer()
    trainer.test_equivariance()


# plot_cnn_mae()
plot_equivariance()
