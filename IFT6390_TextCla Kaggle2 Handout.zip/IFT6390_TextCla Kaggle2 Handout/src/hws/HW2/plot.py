import numpy as np
import pickle
import matplotlib.pyplot as plt

if __name__ == "__main__":


    C_list = [1, 5, 10]
    train_losses = []
    train_accs = []
    test_losses = []
    test_accs = []
    for i in range(3):
        with open('dict_C='+str(C_list[i])+'.pkl', 'rb') as f:
            result = pickle.load(f)
        
        train_losses.append(result['train_losses'])
        train_accs.append(result['train_accs'])
        test_losses.append(result['test_losses'])
        test_accs.append(result['test_accs'])

    # train_losses
    plt.plot(train_losses[0], 'r', label='C=1')
    plt.plot(train_losses[1], 'b', label='C=5') 
    plt.plot(train_losses[2], 'g', label='C=10') 
    plt.legend()
    plt.xlabel('n_iter')
    plt.ylabel('loss')
    plt.title('Curves of train losses')
    plt.show()

    # train_accs 
    plt.plot(train_accs[0], 'r', label='C=1')
    plt.plot(train_accs[1], 'b', label='C=5') 
    plt.plot(train_accs[2], 'g', label='C=10') 
    plt.legend()
    plt.xlabel('n_iter')
    plt.ylabel('loss')
    plt.title('Curves of train accuracy')
    plt.show()

    # test_losses
    plt.plot(test_losses[0], 'r', label='C=1')
    plt.plot(test_losses[1], 'b', label='C=5') 
    plt.plot(test_losses[2], 'g', label='C=10') 
    plt.legend()
    plt.xlabel('n_iter')
    plt.ylabel('loss')
    plt.title('Curves of test losses')
    plt.show()

    # test_accs
    plt.plot(test_accs[0], 'r', label='C=1')
    plt.plot(test_accs[1], 'b', label='C=5') 
    plt.plot(test_accs[2], 'g', label='C=10') 
    plt.legend()
    plt.xlabel('n_iter')
    plt.ylabel('loss')
    plt.title('Curves of test accuracy')
    plt.show()
