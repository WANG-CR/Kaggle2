import torch.nn as nn
from transformers.modeling_outputs import TokenClassifierOutput

from utils.func import init_random_state
from transformers import PreTrainedModel


class BertClassifier(PreTrainedModel):
    def __init__(self, model, n_labels, loss_func, dropout=0.1, seed=0):
        super().__init__(model.config)
        self.bert_encoder, self.loss_func = model, loss_func
        self.dropout = nn.Dropout(dropout)
        self.classifier = nn.Linear(model.config.hidden_size, n_labels)  # load and initialize weights
        init_random_state(seed)

    def forward(self, **input):
        # Extract outputs from the model
        labels = input.pop("labels")
        outputs = self.bert_encoder(**input, output_hidden_states=True)
        emb = self.dropout(outputs['hidden_states'][-1])  # outputs[0]=last hidden state
        # Use CLS Emb as sentence emb.
        cls_token_emb = emb.permute(1, 0, 2)[0]
        logits = self.classifier(cls_token_emb)
        
        if labels.shape[-1] == 1:
            labels = labels.squeeze()
        loss = self.loss_func(logits, labels)
        return TokenClassifierOutput(loss=loss, logits=logits)

    def save_pretrained(self, output_dir, state_dict):
        return self.bert_encoder.save_pretrained(output_dir, state_dict=state_dict, save_config=True)
