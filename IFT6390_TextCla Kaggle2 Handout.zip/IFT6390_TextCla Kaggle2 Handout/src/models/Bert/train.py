import os.path as osp
import sys

sys.path.append((osp.abspath(osp.dirname(__file__)).split('src')[0] + 'src'))
from utils.func import time_logger
from models.Bert.config import BertConfig


@time_logger
def train_paper_classification(args):
    # ! Init Arguments
    cf = BertConfig(args).init()

    # ! Import packages
    # Note that the assignment of GPU-ID must be specified before torch/dgl is imported.
    from models.Bert.trainer import BertTextClaTrainer

    # ! Load data and train
    trainer = BertTextClaTrainer(cf=cf)
    trainer.train()
    trainer.eval_and_save()
    return cf


if __name__ == "__main__":
    args = BertConfig().parse_args()
    train_paper_classification(args)
