import os
from utils.modules.model_conf import ModelConfig, SubConfig
from utils.settings import *
import utils.func as uf


class BertConfig(ModelConfig):
    def __init__(self, args=None):
        # ! INITIALIZE ARGS
        super(BertConfig, self).__init__('Bert')

        # ! Tokenizer Settings
        self.vocab_size = 30000
        self.min_frequency = 5

        # ! Bert Settings
        self.base_model = 'microsoft/deberta-base'
        self.base_model = 'microsoft/deberta-v3-base'
        self.base_model = 'bert-base-uncased'
        self.lr = 0.00003
        self.eq_batch_size = 128
        self.weight_decay = 0.01
        self.label_smoothing_factor = 0.1
        self.cla_dropout = 0.1
        # Not used parameters
        self.dropout = 0.1
        self.att_dropout = 0.1

        # ! Other settings
        self.warmup_epochs = 0.6
        self.eval_freq_per_epoch = 3

        # ! POST_INIT
        self._post_init(args)

    # *  <<<<<<<<<<<<<<<<<<<< POST INIT FUNCS >>>>>>>>>>>>>>>>>>>>

    def _intermediate_args_init(self):
        """
        Parse intermediate settings that shan't be saved or printed.
        """
        self.lm_model = self.base_model
        self.local_rank = -1 if 'LOCAL_RANK' not in os.environ else int(os.environ['LOCAL_RANK'])

    def _sub_conf_init(self):
        super()._sub_conf_init()
        self.lm = SubConfig(self, self.para_prefix)

    def _exp_init(self):
        super()._exp_init()
        # ! Batch_size Setting
        max_bsz_lookup_dict = {12: 64, 16: 128, 24: 128, 32: 128}
        self.batch_size, self.grad_acc_steps = uf.calc_bsz_grad_acc(self.eq_batch_size, max_bsz_lookup_dict, SV_INFO)

    def _data_args_init(self):
        # Dataset
        self.cut_off = 512

    # *  <<<<<<<<<<<<<<<<<<<< SUB MODULES >>>>>>>>>>>>>>>>>>>>

    # *  <<<<<<<<<<<<<<<<<<<< PATH RELATED >>>>>>>>>>>>>>>>>>>>
    para_prefix = {'base_model': '', 'lr': 'lr', 'eq_batch_size': 'bsz', 'weight_decay': 'wd', 'dropout': 'do',
                   'att_dropout': 'atdo', 'cla_dropout': 'cla_do', 'label_smoothing_factor': 'lbs',
                   'epochs': 'e', 'warmup_epochs': 'we', }

    @property
    def tokenizer_cf(self):
        return f'{self.vocab_size}tokens_freq{self.min_frequency}'

    @property
    def tokenizer_path(self):
        return f'{DATA_PATH}/tokenizer/{self.tokenizer_cf}/'

    @property
    def out_temp_dir(self):
        return f'{TEMP_PATH}{self.model}/ckpts/{self.model_cf_str}/{self.tokenizer_cf}'

    @property
    def out_ckpt_dir(self):
        return f'output/{self.model}/ckpts/{self.model_cf_str}/'

    @property
    def model_cf_str(self):
        return self.lm.f_prefix + self.tokenizer_cf

    # *  <<<<<<<<<<<<<<<<<<<< MISC >>>>>>>>>>>>>>>>>>>>
