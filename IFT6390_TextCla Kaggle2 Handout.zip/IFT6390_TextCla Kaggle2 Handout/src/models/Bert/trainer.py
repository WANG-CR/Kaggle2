from time import time
import torch as th
from datasets import load_metric
from transformers import AutoModel, EvalPrediction, TrainingArguments, Trainer, BertModel, BertConfig

import utils.func as uf
from models.Bert import BertClassifier, Config, BertForSequenceClassification
from utils.modules.trainer import TextClaTrainer
from utils.data.datasets import TextClaDataset
import logging
import pandas as pd
import wandb
from utils.func import *
from transformers import AutoTokenizer, AutoConfig, AutoModelForSequenceClassification
from utils.settings import *
from utils.data.tokenization import load_tokenizer
import numpy as np

METRIC_LIST = ['accuracy', 'precision', 'recall']  #
METRIC_LIST = {  # metric -> metric_path # For offline usage
    'accuracy': 'src/_utils/metrics/hf_accuracy.py',
    # 'f1score': 'src/_utils/metrics/hf_f1.py',
    # 'precision': 'src/_utils/metrics/hf_precision.py',
    # 'recall': 'src/_utils/metrics/hf_recall.py',
}


class BertTextClaTrainer(TextClaTrainer):
    """Convert textural graph to text list"""

    def __init__(self, cf: Config):
        # Load data
        super(BertTextClaTrainer, self).__init__(cf)
        self.cf = cf
        text_splits = [self.train_x, self.val_x, self.test_x]
        labels = [self.train_y, self.val_y, np.zeros(len(self.test_x)).astype(int)]
        corpus = np.concatenate(text_splits)

        tokenizer = load_tokenizer(cf, corpus)

        if os.path.exists(f := f'data/{cf.tokenizer_cf}tokenized{cf.process_mode}_{MAX_DATA_SAMPLES}.pkl'):
            tokenized = pickle_load(f)
        else:
            tokenize = lambda x: tokenizer(x[:MAX_DATA_SAMPLES].tolist(), padding='max_length',
                                           truncation=True, max_length=64)
            tokenized = [tokenize(_).data for _ in text_splits]
            pickle_save(tokenized, f)
        logging.getLogger("transformers.tokenization_utils_base").setLevel(logging.ERROR)
        # logging.set_verbosity_error()

        self.model = None
        self.tr_data, self.val_data, self.test_data = [
            TextClaDataset(*_) for _ in zip(tokenized, labels)]
        self.metrics = {m: load_metric(m) for m in METRIC_LIST}
        bert_conf = BertConfig(hidden_dropout_prob=cf.dropout, attention_probs_dropout_prob=cf.att_dropout,
                               vocab_size=cf.vocab_size + 10)
        self.model = BertForSequenceClassification(
            bert_conf, self.cf.n_class,
            loss_func=th.nn.CrossEntropyLoss(label_smoothing=self.cf.label_smoothing_factor)
        )

        # self.model = BertClassifier(
        #     BertModel(self.bert_conf), self.cf.n_class,
        #     dropout=self.cf.cla_dropout,
        #     loss_func=th.nn.CrossEntropyLoss(label_smoothing=self.cf.label_smoothing_factor)
        # )

    def train(self):
        eval_steps = min(MAX_DATA_SAMPLES, 100000) // self.cf.eq_batch_size
        train_steps = len(self.train_x) / self.cf.eq_batch_size
        args = TrainingArguments(
            output_dir=self.cf.out_temp_dir,
            evaluation_strategy='steps',
            eval_steps=eval_steps,
            save_strategy='steps',
            save_steps=eval_steps,
            learning_rate=self.cf.lr, weight_decay=self.cf.weight_decay,
            load_best_model_at_end=True, gradient_accumulation_steps=self.cf.grad_acc_steps,
            save_total_limit=1,
            report_to='wandb' if self.cf.wandb_on else None,
            per_device_train_batch_size=self.cf.batch_size,
            per_device_eval_batch_size=128,
            warmup_steps=50,
            disable_tqdm=False,
            # dataloader_drop_last=True,  # ! Will drop last batch !!!!!
            dataloader_drop_last=False,
            num_train_epochs=self.cf.epochs,
            # num_train_epochs=0.0005,  # For DEBUG ONLY
            local_rank=self.cf.local_rank,
        )

        # ! Get dataloader
        def compute_metrics(pred: EvalPrediction):
            predictions, references = pred.predictions.argmax(1), pred.label_ids
            if self.cf.wandb_on:
                # ROC
                wandb.log({f"{self.eval_phase}-ROC": wandb.plot.roc_curve(
                    references, pred.predictions, labels=self.cf.label_name, title=f"{self.eval_phase}-ROC")})
                # PR
                wandb.log({f"{self.eval_phase}-PR": wandb.plot.pr_curve(
                    references, pred.predictions, labels=self.cf.label_name, title=f"{self.eval_phase}-PR")})
            return {m_name: metric.compute(predictions=predictions, references=references) for m_name, metric in
                    self.metrics.items()}

        self.trainer = Trainer(
            model=self.model,
            args=args,
            train_dataset=self.tr_data,
            eval_dataset=self.val_data,
            compute_metrics=compute_metrics,
        )
        self.eval_phase = 'Eval'
        self.trainer.train()

    def eval_and_save(self):
        def get_metric(split='valid'):
            self.eval_phase = 'Test' if split == 'test' else 'Eval'
            mtc_dict = self.trainer.predict(self.val_data).metrics
            ret = {f'{split}_{_}': mtc_dict[m][_] for m in mtc_dict if (_ := m.split('_')[-1]) in METRIC_LIST}
            return ret

        result = get_metric('valid')
        val_acc = result["valid_accuracy"]
        res = {"res_file": self.cf.res_file, **result}
        self.logger.dynamic_log(result)
        self.logger.log(f'\nTrain seed{self.cf.seed} finished\nResults: {res}\n{self.cf}')
        self.logger.static_log(self.cf.model_conf)
        self.logger.static_log(res)
        self.logger.save()

        # ! Save checkpoint
        # uf.remove_file(f'{self.cf.out_temp_dir}')
        if val_acc > 0.82:
            if self.cf.local_rank <= 0:
                self.model.save_pretrained(self.cf.out_ckpt_dir)
                # th.save(self.model.state_dict(), uf.init_path(self.cf.out_ckpt_dir))

            # ! Save test
            f = uf.init_path(f'output/test_pred@Val{val_acc:.5f}.csv')
            test_preds = self.trainer.predict(self.test_data)
            pred = np.argmax(test_preds.predictions, axis=1).astype('str')
            self.save_test(pred, f)
