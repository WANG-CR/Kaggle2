import os
import warnings

# ! Import packages
proj_path = '/home/mila/j/jianan.zhao/scratch/IFT6390_TextCla/'
os.chdir(proj_path)
warnings.filterwarnings('ignore')

from explainability.BERT_explainability.modules.BERT.BertForSequenceClassification import BertForSequenceClassification
from transformers import BertTokenizer
from explainability.BERT_explainability.modules.BERT.ExplanationGenerator import Generator
from models.Bert.config import BertConfig
from models.Bert.trainer import BertTextClaTrainer, TrainingArguments
from types import SimpleNamespace as SN
import numpy as np
from transformers import Trainer

import torch
from captum.attr import visualization
from functools import partial


def explain_sentence(tokenizer, explanations, model,
                     text=[
                         "This movie was the best movie I have ever seen! some scenes were ridiculous, but acting was great."],
                     true_class=2
                     ):
    classifications = ["NEGATIVE", "NEURAL", "POSITIVE"]
    # encode sentences
    encoding = tokenizer(text, padding=True, return_tensors='pt')
    input_ids = encoding['input_ids'].to("cuda")
    attention_mask = encoding['attention_mask'].to("cuda")

    # generate an explanation for the input
    expl = explanations.generate_LRP(input_ids=input_ids, attention_mask=attention_mask, start_layer=0)[0]
    # normalize scores
    expl = (expl - expl.min()) / (expl.max() - expl.min())

    # get the model classification
    output = torch.nn.functional.softmax(model(input_ids=input_ids, attention_mask=attention_mask)[0], dim=-1)
    classification = output.argmax(dim=-1).item()
    # get class name
    class_name = classifications[classification]
    # if the classification is negative, higher explanation scores are more negative
    # flip for visualization
    if class_name == "NEGATIVE":
        expl *= (-1)

    tokens = tokenizer.convert_ids_to_tokens(input_ids.flatten())
    print([(tokens[i], expl[i].item()) for i in range(len(tokens))])
    vis_data_records = [visualization.VisualizationDataRecord(
        expl,
        output[0][classification],
        classification,
        true_class,
        true_class,
        1,
        tokens,
        1)]
    visualization.visualize_text(vis_data_records)
#
#
# # ckpt = 'output/Bert/ckpts/bert-base-uncased_lr2e-05_bsz72_wd0.01_do0.1_atdo0.1_cla_do0.1_lbs0.1_e3_we060000tokens_freq5/'
# ckpt = '/home/mila/j/jianan.zhao/scratch/IFT6390_TextCla/output/Bert/ckpts/bert-base-uncased_lr3e-05_bsz128_wd0.01_do0.1_atdo0.1_cla_do0.1_lbs0.0_e8_we030000tokens_freq5'
# # ckpt = '/home/mila/j/jianan.zhao/scratch/IFT6390_TextCla/output/Bert/ckpts/bert-base-uncased_lr3e-05_bsz128_wd0.01_do0.1_atdo0.1_cla_do0.1_lbs0.0_e8_we010000tokens_freq5'
# tokenizer_path = 'data/tokenizer/60000tokens_freq5/vocab.txt'
# model = BertForSequenceClassification.from_pretrained(ckpt, num_labels=3).to("cuda")
# model.eval()
# tokenizer = BertTokenizer.from_pretrained(tokenizer_path)
# explanations = Generator(model)
# explain = partial(explain_sentence, tokenizer=tokenizer, explanations=explanations)
#
# # ! Init Arguments
# cf = BertConfig(SN(wandb_name='OFF')).init()
# trainer = BertTextClaTrainer(cf=cf)
# val_x, val_y = trainer.val_x, trainer.val_y
#
# # ! Predict
# hf_trainer = Trainer(args=TrainingArguments(per_device_eval_batch_size=300, output_dir='temp')
#                      , model=model)
# pred = hf_trainer.predict(trainer.val_data)
# y_pred = np.argmax(pred.predictions, axis=-1)
#
# import utils.func as uf
#
# uf.pickle_save(y_pred, 'temp/check_explainability.pred')
#
# from sklearn.metrics import classification_report
#
# print(classification_report(y_pred, val_y))
#
# correct_pos_text = val_x[val_y == 2 and val_y == y_pred][:5].tolist()
# incorrect_pos_text = val_x[val_y == 2 and val_y != y_pred][:5].tolist()
#
# correct_neg_text = val_x[val_y == 1 and val_y == y_pred][:5].tolist()
# incorrect_neg_text = val_x[val_y == 1 and val_y != y_pred][:5].tolist()
# correct_neu_text = val_x[val_y == 0 and val_y == y_pred][:5].tolist()
# incorrect_neu_text = val_x[val_y == 0 and val_y != y_pred][:5].tolist()
# # from explainability.explain_utils import explain_sentence
#
# for text in correct_pos_text:
#     explain(text=text)
#
# for text in incorrect_pos_text:
#     explain(text=text)
#
# for text in correct_neg_text:
#     explain(text=text)
#
# for text in incorrect_neg_text:
#     explain(text=text)
#
# for text in correct_neu_text:
#     explain(text=text)
#
# for text in incorrect_neu_text:
#     explain(text=text)
