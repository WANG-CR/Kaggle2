import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import sklearn
from sklearn.naive_bayes import MultinomialNB, BernoulliNB
from sklearn.feature_extraction.text import CountVectorizer
import pickle

def load_dataset():
    train_data = pd.read_csv('data/train_data.csv')['text']
    test_data = pd.read_csv('data/test_data.csv')['text']
    
    counts = {"negative": 0, "neutral": 0, "positive":0}
    train_label = pd.read_csv('data/train_results.csv')
    train_label = np.array([list(counts).index(i) for i in train_label["target"]])
    return train_data, train_label, test_data

def train_tokenizer(train_data, max_features):
    vectorizer = CountVectorizer(min_df=1, lowercase=True, max_features=max_features)
    vectorizer.fit(train_data)
    return vectorizer

def vectorize(vectorizer, text):
    BOW = vectorizer.transform(text).toarray()
    return BOW 

def save_df(test_labels, save_as_name):
    df = pd.DataFrame({'target':test_labels})
    df.index.name = 'id'
    df.to_csv(save_as_name + ".csv")
    print('save to: ' + save_as_name + '.csv')



def train_evaluate_model(train_feature, train_label, train_length, model_name= "Multinomial", return_model=False):
    # train model
    if model_name == "Multinomial":
        model_NB = MultinomialNB()
    else:
        model_NB = BernoulliNB()
    model_NB.fit(train_feature[0:train_length], train_label[0:train_length])

    # evaluate model
    valid_labels = model_NB.predict(train_feature[train_length:-1])
    accuracy = valid_labels == train_label[train_length:-1]

    if not return_model:
        return model_NB
    else:
        return np.mean(accuracy)


def test_max_features(train_data, train_label, model_name = "Multinomial"):
    max_features_list = [20, 100, 500, 2000]
    # max_features_list = [5000]
    # , 5000
    accuracy = []
    for max_features in max_features_list:
        vectorizer= train_tokenizer(train_data, max_features)
        train_feature = vectorize(vectorizer, train_data)
        train_length =int(0.9*train_feature.shape[0]) 
        model_NB, acc = train_evaluate_model(train_feature, train_label, train_length, model_name)
        accuracy.append(acc)
        print(accuracy)
    return max_features_list, accuracy



train_data, train_label, test_data = load_dataset()
with open('preprocess_test.txt', 'rb') as fp:
    test_data = pickle.load(fp)
with open('preprocess_train.txt', 'rb') as fp:
    train_data = pickle.load(fp)

max_features=2000
vectorizer= train_tokenizer(train_data, max_features)
train_feature = vectorize(vectorizer, train_data)
test_feature = vectorize(vectorizer, test_data)
train_length =int(0.9*train_feature.shape[0]) 


### train model
model_NB= train_evaluate_model(train_feature, train_label, train_length, return_model=True)

### predict with model
test_labels = model_NB.predict(test_feature)
save_df(test_labels, "NB_Multinomial_2000feature")

