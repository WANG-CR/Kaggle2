import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import sklearn
from sklearn.naive_bayes import MultinomialNB
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.svm import SVC

import nltk
from nltk.stem import WordNetLemmatizer
from nltk.corpus import stopwords

import re
import pickle

def load_dataset():
    train_data = pd.read_csv('data/train_data.csv')['text']
    test_data = pd.read_csv('data/test_data.csv')['text']
    
    counts = {"negative": 0, "neutral": 0, "positive":0}
    train_label = pd.read_csv('data/train_results.csv')
    train_label = np.array([list(counts).index(i) for i in train_label["target"]])
    return train_data, train_label, test_data

def preprocess_data(data):
    cleanedData = []
    lemma = WordNetLemmatizer()
    swords = stopwords.words("english")
    for text in data:
    # Cleaning links
        text = re.sub(r'http\S+', '', text)
        
        # Cleaning everything except alphabetical and numerical characters
        text = re.sub("[^a-zA-Z0-9]"," ",text)
        
        # Tokenizing and lemmatizing
        text = nltk.word_tokenize(text.lower())
        text = [lemma.lemmatize(word) for word in text]
        
        # Removing stopwords
        text = [word for word in text if word not in swords]
        
        # Joining
        text = " ".join(text)
        # print(f"text processed is: {text}")
        cleanedData.append(text)
    return cleanedData




train_data, train_label, test_data = load_dataset()


test_data = preprocess_data(test_data)
with open("preprocess_test.txt", "wb") as fp:   #Pickling
    pickle.dump(test_data, fp)
print(f"first test sample is {test_data[0]}")
print(f"test data shape after preprocessing is {len(test_data)}")


train_data = preprocess_data(train_data)
print(f"finish preprocessing train data")
with open("preprocess_train.txt", "wb") as fp:   #Pickling
    pickle.dump(train_data, fp)
