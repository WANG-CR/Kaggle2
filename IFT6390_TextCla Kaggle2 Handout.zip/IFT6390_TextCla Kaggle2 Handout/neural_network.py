from tqdm import tqdm
import math
import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import sklearn
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.naive_bayes import MultinomialNB
from sklearn.feature_extraction.text import CountVectorizer

def load_dataset():
    train_data = pd.read_csv('data/train_data.csv')['text']
    test_data = pd.read_csv('data/test_data.csv')['text']
    
    counts = {"negative": 0, "neutral": 0, "positive":0}
    train_label = pd.read_csv('data/train_results.csv')
    train_label = np.array([list(counts).index(i) for i in train_label["target"]])
    return train_data, train_label, test_data

def train_tokenizer(train_data, num_features):
    vectorizer = CountVectorizer(min_df=1, lowercase=True, max_features=num_features)
    vectorizer.fit(train_data)
    return vectorizer

def vectorize(vectorizer, text):
    BOW = vectorizer.transform(text).toarray()
    return BOW 

def process_features(vectorize, train_data, test_data):
    train_feature = vectorize(vectorizer, train_data)
    test_feature = vectorize(vectorizer, test_data)
    return train_feature, test_feature

def save_df(test_labels, save_as_name):
    df = pd.DataFrame({'target':test_labels})
    df.index.name = 'id'
    df.to_csv('result/'+save_as_name + ".csv")
    print('save to: ' + save_as_name + '.csv')

#define model
class Net(nn.Module):
    def __init__(self, n_feat):
        super().__init__()
        self.MLP = torch.nn.Sequential(
            torch.nn.Linear(n_feat, n_feat),
            torch.nn.ReLU(),
            torch.nn.Dropout(p=0.2),
            torch.nn.Linear(n_feat, 3)
        )

    def forward(self, x):
        x = self.MLP(x)
        return x

# define dataset loading module
class Dataset(torch.utils.data.Dataset):
  'Characterizes a dataset for PyTorch'
  def __init__(self, feature, labels):
        'Initialization'
        self.feature = feature
        self.labels = labels

  def __len__(self):
        'Denotes the total number of samples'
        return self.labels.shape[0]

  def __getitem__(self, index):
        'Generates one sample of data'
        # Load data and get label
        X = self.feature[index]
        y = self.labels[index]
        return X, y



# do evaluation on valid
def evaluate(net, validation_generator):
    net.eval()
    precision = 0
    for i, data in enumerate(validation_generator, 0):
        # get the inputs; data is a list of [inputs, labels]
        inputs, labels = data
        # forward + backward + optimize
        outputs = net(inputs.to(device))
        # print(f"labels is {labels}")
        precision += outputs.argmax(-1) == labels.to(device)
    print(f"final precision is {precision/valid_length}")
    return precision.item()/valid_length


# parameters control
num_features = 2000
num_epoch = 20
batch_size = 64



# preprocessing
train_data, train_label, test_data = load_dataset()
vectorizer= train_tokenizer(train_data, num_features)
train_feature, test_feature = process_features(vectorize, train_data, test_data)

#split and create dataset
train_feature = torch.from_numpy(train_feature)
test_feature = torch.from_numpy(test_feature).type(torch.float32)
train_label = torch.from_numpy(train_label)
train_feature_label = torch.concat((train_feature, train_label[..., None]), dim=-1)
print(f"train_feature_label shape is {train_feature_label.shape}")
train_length =int(0.9*train_feature_label.shape[0]) 
valid_length = train_feature_label.shape[0] - train_length
train_set = train_feature_label[0:train_length]
valid_set = train_feature_label[train_length:-1]


params = {'batch_size': batch_size,
          'shuffle': True,
          'num_workers': 6}
params_valid = {'batch_size': 1,
          'shuffle': False,
          'num_workers': 6}
train_dataset = Dataset(train_set[..., :-1].type(torch.float32), train_set[..., -1])
valid_dataset = Dataset(valid_set[..., :-1].type(torch.float32), valid_set[..., -1])
training_generator = torch.utils.data.DataLoader(train_dataset, **params)
validation_generator = torch.utils.data.DataLoader(valid_dataset, **params_valid)

# initialize training components
device = torch.device('cuda')
net = Net(num_features).to(device)
import torch.optim as optim
criterion = nn.CrossEntropyLoss()
optimizer = optim.SGD(net.parameters(), lr=0.001, momentum=0.9)


train_acc = []
train_loss = []

# training process
for epoch in range(num_epoch):  # loop over the dataset multiple times
    net.train()
    running_loss = 0.0
    for i, data in enumerate(training_generator, 0):
        # get the inputs; data is a list of [inputs, labels]
        inputs, labels = data

        # zero the parameter gradients
        optimizer.zero_grad()

        # forward + backward + optimize
        outputs = net(inputs.to(device))
        loss = criterion(outputs, labels.to(device))
        loss.backward()
        optimizer.step()

        # print statistics
        running_loss += loss.detach().item()
        # if i % 6000 == 5999:    # print every 2000 mini-batches
        #     print(f'[{epoch + 1}, {i + 1:5d}] loss: {running_loss / 6000:.3f}')
        #     running_loss = 0.0
    train_loss.append(running_loss/train_length)
    train_acc.append(evaluate(net, validation_generator))
    print(f"train_loss is {train_loss}")
    print(f"train_acc is {train_acc}")
print('Finished Training')


# save test
net.eval()
test_labels = net(test_feature.to(device))
print(f"test labelshape is {test_labels.shape}")
save_df(test_labels.detach().argmax(-1).cpu().numpy().tolist(), "NN_" + str(num_features) + "feature_" + str(num_epoch) + "epoch")