import os.path as osp
import sys

sys.path.append((osp.abspath(osp.dirname(__file__)).split('src')[0] + 'src'))
from utils.modules.model_conf import get_conf_and_trainer

if __name__ == "__main__":
    # ! Init Arguments
    Config, Trainer = get_conf_and_trainer()
    args = Config().parse_args()
    cf = Config(args).init()

    # # ! Load data and train
    # trainer = Trainer(cf)
    # trainer.train()
    # trainer.eval_and_save_test()
    import pandas as pd

    df_pred = pd.read_csv(f := 'output/test_pred@Val0.87054.csv')
    _ = {2: 'positive', 0: 'negative', 1: 'neutral'}
    df_pred['target'] = df_pred['Target'].replace(_)
    df_pred['id'] = df_pred['Id']
    df_out = df_pred[['id', 'target']]
    df_out.to_csv(f, index=False)
